module.exports = {
    default: {
        src: ['<%= yeoman.src %>/**/*.js']
    }
};
